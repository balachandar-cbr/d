# DCN Lab (PCA25C08J) - Python Programs

Setup:   python -m venv venv && venv\Scripts\activate   (Windows)
                                source venv/bin/activate   (Linux/Mac)
         pip install -r requirements.txt

| Ex | File | Run |
|----|------|-----|
| 3  | ex03_network_performance.py | python ex03_network_performance.py |
| 4  | ex04_crc.py | python ex04_crc.py |
| 5  | ex05_parity.py | python ex05_parity.py |
| 6  | ex06_hamming.py | python ex06_hamming.py |
| 7  | ex07_stop_and_wait.py | python ex07_stop_and_wait.py |
| 8  | ex08_char_stuffing.py | python ex08_char_stuffing.py |
| 11 | ex11_encryption.py | python ex11_encryption.py |
| 12 | ex12_server.py + ex12_client.py | Terminal 1: server, Terminal 2: client (same choice) |
| 13 | ex13_dns_http.py | python ex13_dns_http.py |
| 15 | ex15_rest_api.py | python ex15_rest_api.py, then open http://127.0.0.1:5000 |

Ex 1, 2, 9 -> Cisco Packet Tracer; Ex 10 -> Wireshark; Ex 14 -> FileZilla/Thunderbird/telnet/ssh (no Python files).
